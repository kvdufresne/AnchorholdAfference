module Jekyll
  module Roman
    VERSION = "0.0.2"
  end
end
